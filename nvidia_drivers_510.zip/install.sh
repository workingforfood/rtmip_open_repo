#!/bin/bash
set -e
apt install -y nvidia-driver-510
apt install -y nvidia-driver-510-server

